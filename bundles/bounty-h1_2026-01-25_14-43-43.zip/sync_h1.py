#!/usr/bin/env python3
import os
import sys
import time
import json
import requests

import psycopg
from psycopg.types.json import Json
from dotenv import load_dotenv

load_dotenv(".env")

DB_DSN = os.getenv("DB_DSN")
H1_USERNAME = os.getenv("H1_USERNAME")
H1_TOKEN = os.getenv("H1_TOKEN")

if not DB_DSN:
    raise RuntimeError("Missing DB_DSN in .env")
if not H1_USERNAME or not H1_TOKEN:
    raise RuntimeError("Missing H1_USERNAME/H1_TOKEN in .env")

API = "https://api.hackerone.com/v1"
AUTH = (H1_USERNAME, H1_TOKEN)

SCOPES_ONLY_BOUNTY = os.getenv("SCOPES_ONLY_BOUNTY", "false").strip().lower() == "true"


def log(msg: str):
    ts = time.strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def get_json(url, params=None):
    r = requests.get(url, auth=AUTH, params=params, timeout=60)
    ct = (r.headers.get("content-type", "") or "").lower()
    data = r.json() if ct.startswith("application/json") else None
    return r.status_code, r.text, data


def upsert_program(conn, prog_id: str, handle: str | None, name: str | None, offers_bounties,
                  currency: str | None, policy: str | None, raw_obj: dict):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO programs(platform, external_id, handle, name, offers_bounties, currency, policy, raw_json, first_seen_at, last_seen_at)
            VALUES ('hackerone', %s, %s, %s, %s, %s, %s, %s::jsonb, now(), now())
            ON CONFLICT (platform, external_id)
            DO UPDATE SET
              handle=EXCLUDED.handle,
              name=EXCLUDED.name,
              offers_bounties=EXCLUDED.offers_bounties,
              currency=EXCLUDED.currency,
              policy=EXCLUDED.policy,
              raw_json=EXCLUDED.raw_json,
              last_seen_at=now();
            """,
            (prog_id, handle, name, offers_bounties, currency, policy, json.dumps(raw_obj)),
        )


def parse_scope_fields(scope_obj: dict) -> tuple[str | None, str | None, bool, str | None]:
    """
    Structured scopes payload can vary. We try common keys.
    Returns: (asset_type, identifier, eligible_for_bounty, instruction)
    """
    attrs = scope_obj.get("attributes", {}) or {}

    asset_type = (attrs.get("asset_type") or attrs.get("type") or attrs.get("asset_kind"))
    identifier = (attrs.get("identifier") or attrs.get("asset_identifier") or attrs.get("asset") or attrs.get("value"))

    # Eligibility fields may differ
    elig = attrs.get("eligible_for_bounty")
    if elig is None:
        elig = attrs.get("eligible_for_submission")
    if elig is None:
        elig = True  # default permissivo; meglio non perdere scope

    instruction = attrs.get("instruction") or attrs.get("description") or attrs.get("notes")

    if isinstance(asset_type, str):
        asset_type = asset_type.strip()
    if isinstance(identifier, str):
        identifier = identifier.strip()
    if isinstance(instruction, str):
        instruction = instruction.strip()

    return asset_type, identifier, bool(elig), instruction


def upsert_scope(cur, program_external_id: str, scope_obj: dict) -> int:
    asset_type, identifier, eligible_for_bounty, instruction = parse_scope_fields(scope_obj)

    # Scope senza identifier non serve a niente
    if not identifier:
        return 0

    cur.execute(
        """
        INSERT INTO scopes (
          platform,
          program_external_id,
          asset_type,
          identifier,
          eligible_for_bounty,
          instruction,
          raw_json,
          first_seen_at,
          last_seen_at
        )
        VALUES ('hackerone', %s,%s,%s,%s,%s,%s,now(),now())
        ON CONFLICT (platform, program_external_id, identifier)
        DO UPDATE SET
          asset_type = EXCLUDED.asset_type,
          eligible_for_bounty = EXCLUDED.eligible_for_bounty,
          instruction = EXCLUDED.instruction,
          raw_json = EXCLUDED.raw_json,
          last_seen_at = now()
        """,
        (
            program_external_id,
            asset_type,
            identifier,
            eligible_for_bounty,
            instruction,
            Json(scope_obj or {}),
        ),
    )
    return 1


def main():
    log("Starting HackerOne sync (FULL)")
    log(f"SCOPES_ONLY_BOUNTY={SCOPES_ONLY_BOUNTY}")
    log(f"DB_DSN={DB_DSN}")

    with psycopg.connect(DB_DSN) as conn:
        conn.autocommit = False

        page = 1
        programs_synced = 0
        scopes_synced = 0
        scopes_404 = 0
        scopes_other_err = 0

        while True:
            st, txt, data = get_json(
                f"{API}/hackers/programs",
                params={"page[number]": page, "page[size]": 100},
            )
            if st != 200 or not data:
                log(f"[FATAL] programs fetch failed HTTP {st}: {txt[:200]}")
                sys.exit(2)

            items = data.get("data", []) or []
            if not items:
                break

            log(f"Programs page {page}: {len(items)} items")

            # upsert programs
            try:
                for it in items:
                    attrs = it.get("attributes", {}) or {}
                    if SCOPES_ONLY_BOUNTY and not attrs.get("offers_bounties"):
                        continue

                    prog_id = str(it.get("id"))
                    handle = (attrs.get("handle") or "").strip() or None
                    name = attrs.get("name")
                    offers_bounties = attrs.get("offers_bounties")
                    currency = attrs.get("currency")
                    policy = attrs.get("submission_state")

                    upsert_program(conn, prog_id, handle, name, offers_bounties, currency, policy, it)
                    programs_synced += 1

                conn.commit()
            except Exception as e:
                conn.rollback()
                log(f"[FATAL] program upsert failed: {type(e).__name__}: {e}")
                sys.exit(3)

            # scopes per program using HANDLE
            for it in items:
                attrs = it.get("attributes", {}) or {}
                if SCOPES_ONLY_BOUNTY and not attrs.get("offers_bounties"):
                    continue

                prog_id = str(it.get("id"))
                handle = (attrs.get("handle") or "").strip()
                if not handle:
                    continue

                url = f"{API}/hackers/programs/{handle}/structured_scopes"
                s_st, s_txt, s_data = get_json(url)

                if s_st == 404:
                    scopes_404 += 1
                    continue
                if s_st != 200 or not s_data:
                    scopes_other_err += 1
                    continue

                scopes = s_data.get("data", []) or []
                try:
                    added = 0
                    with conn.cursor() as cur:
                        for s in scopes:
                            added += upsert_scope(cur, prog_id, s)
                    conn.commit()
                    scopes_synced += added
                except Exception as e:
                    conn.rollback()
                    log(f"[WARN] scope upsert failed for {handle} (id={prog_id}): {type(e).__name__}: {e}")

            page += 1
            if page > 5000:
                break

        log(f"[DONE] programs_synced={programs_synced} scopes_synced={scopes_synced} scopes_404={scopes_404} scopes_other_err={scopes_other_err}")


if __name__ == "__main__":
    main()
