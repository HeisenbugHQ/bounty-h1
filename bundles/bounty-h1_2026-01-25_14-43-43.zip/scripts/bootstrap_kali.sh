#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

echo "[+] Bootstrap Kali (WSL) environment + recon tools"
echo "    repo: $REPO_ROOT"

# -------------------------
# APT deps
# -------------------------
echo "[+] apt: update & install base packages..."
sudo apt update
sudo apt install -y \
  git curl wget unzip jq make gcc g++ \
  ca-certificates build-essential \
  python3 python3-venv python3-pip \
  dnsutils \
  nmap masscan \
  massdns \
  libpcap-dev \
  postgresql-client

# -------------------------
# Go + PATH
# -------------------------
echo "[+] Ensure Go is installed..."
if ! command -v go >/dev/null 2>&1; then
  sudo apt install -y golang-go
fi

GOPATH="$(go env GOPATH)"
GO_BIN="${GOPATH}/bin"
echo "[+] Go: GOPATH=$GOPATH"

echo "[+] Ensure Go bin is in PATH (current shell + persist)..."
export PATH="$PATH:$GO_BIN"

add_path_line() {
  local rc="$1"
  local line='export PATH="$PATH:$(go env GOPATH)/bin"'
  if [ -f "$rc" ]; then
    if ! grep -Fq "$line" "$rc"; then
      echo "$line" >> "$rc"
      echo "  - appended to $rc"
    fi
  else
    echo "$line" >> "$rc"
    echo "  - created $rc"
  fi
}
add_path_line "$HOME/.bashrc"
add_path_line "$HOME/.zshrc"

# -------------------------
# Go tools
# -------------------------
echo "[+] Installing Go tools (subfinder/httpx/naabu/puredns/ffuf)..."
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/projectdiscovery/httpx/cmd/httpx@latest
go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install github.com/d3mondev/puredns/v2@latest
go install github.com/ffuf/ffuf/v2@latest

# -------------------------
# Python venv + deps
# -------------------------
echo "[+] Python: create venv..."
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi

echo "[+] Python: install requirements..."
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip wheel setuptools
pip install -r requirements.txt

# -------------------------
# Wordlists (SMALL only)
# -------------------------
WORDLIST_DIR="${REPO_ROOT}/wordlists"
SMALL_DIR="${WORDLIST_DIR}/small"

mkdir -p "$SMALL_DIR"

download_if_missing() {
  local url="$1"
  local out="$2"
  if [ -s "$out" ]; then
    echo "  [OK] exists: $out"
    return 0
  fi
  echo "  [DL] $url -> $out"
  curl -fsSL "$url" -o "$out"
}

echo "[+] Wordlists: downloading SMALL sets into $SMALL_DIR"

# SMALL subdomains list (SecLists)
# note: this is a good balance for quick tests
download_if_missing \
  "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-5000.txt" \
  "${SMALL_DIR}/subdomains_5000.txt"

# SMALL dirs/paths list (raft-small-words)
download_if_missing \
  "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/raft-small-words.txt" \
  "${SMALL_DIR}/raft-small-words.txt"

# optional: small extensions (useful later if vuoi)
download_if_missing \
  "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/web-extensions.txt" \
  "${SMALL_DIR}/web-extensions.txt"

# Create "project standard" filenames used by workers (stable paths)
# subdomain bruteforce worker expects wordlists/subdomains_small.txt by default
# dir fuzz worker expects wordlists/paths_small.txt by default
echo "[+] Wordlists: creating stable SMALL aliases..."

ln -sf "${SMALL_DIR}/subdomains_5000.txt" "${WORDLIST_DIR}/subdomains_small.txt"
ln -sf "${SMALL_DIR}/raft-small-words.txt" "${WORDLIST_DIR}/paths_small.txt"

# -------------------------
# Resolvers
# -------------------------
echo "[+] Resolvers: ensure resolvers.txt exists..."
if [ ! -s "${REPO_ROOT}/resolvers.txt" ]; then
  echo "  [DL] resolvers_seed -> resolvers.txt"
  # Trickest resolvers list (seed). We keep it simple for now.
  curl -fsSL "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt" -o "${REPO_ROOT}/resolvers.txt" || true
fi

if [ ! -s "${REPO_ROOT}/resolvers.txt" ]; then
  echo "  [WARN] resolvers.txt not available (offline?). Writing minimal fallback."
  cat > "${REPO_ROOT}/resolvers.txt" <<'TXT'
1.1.1.1
1.0.0.1
8.8.8.8
8.8.4.4
9.9.9.9
208.67.222.222
208.67.220.220
TXT
fi

# -------------------------
# Sanity checks
# -------------------------
echo "[+] Sanity checks:"
echo "    massdns:   $(command -v massdns || echo MISSING)"
echo "    subfinder: $(command -v subfinder || echo MISSING)"
echo "    httpx:     $(command -v httpx || echo MISSING)"
echo "    naabu:     $(command -v naabu || echo MISSING)"
echo "    puredns:   $(command -v puredns || echo MISSING)"
echo "    ffuf:      $(command -v ffuf || echo MISSING)"
echo "    psql:      $(command -v psql || echo MISSING)"
echo "    python:    $(python --version)"
echo "    resolvers: $(wc -l < resolvers.txt | tr -d ' ') lines"
echo "    wordlists: subdomains_small=$(wc -l < wordlists/subdomains_small.txt | tr -d ' ')  paths_small=$(wc -l < wordlists/paths_small.txt | tr -d ' ')"

echo
echo "[+] Done."
echo "Next:"
echo "  - restart shell OR: source ~/.zshrc (to persist PATH)"
echo "  - activate venv: source .venv/bin/activate"
echo "  - quick test:"
echo "      puredns resolve <(printf \"google.com\\n\") -r resolvers.txt --write /tmp/resolved.txt && cat /tmp/resolved.txt"
