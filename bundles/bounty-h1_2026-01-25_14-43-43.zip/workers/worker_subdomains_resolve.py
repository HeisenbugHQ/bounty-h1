#!/usr/bin/env python3
"""
workers/worker_subdomains_resolve.py

Subdomain enumeration + resolution gate:
- subfinder -> candidates
- puredns resolve -> resolved only
- insert resolved into targets (low-noise input for httpx/ports/enrich)

Env (.env):
  DB_DSN=postgresql://bounty:bounty@127.0.0.1:5432/bountydb

Optional:
  ONLY_BOUNTY_PROGRAMS=true
  SUBFINDER_BIN=subfinder
  PUREDNS_BIN=puredns
  RESOLVERS_FILE=resolvers.txt
  SUBFINDER_TIMEOUT=120
  PUREDNS_TIMEOUT=180
  SUBFINDER_ALL=true
  SUBFINDER_RECURSIVE=false
  SAVE_DISCOVERIES=true
"""

import os
import re
import subprocess
import tempfile
from urllib.parse import urlparse

import psycopg
from dotenv import load_dotenv

load_dotenv(".env")

DB_DSN = os.getenv("DB_DSN")
if not DB_DSN:
    raise RuntimeError("Missing DB_DSN in .env")

ONLY_BOUNTY = os.getenv("ONLY_BOUNTY_PROGRAMS", "true").strip().lower() == "true"
SUBFINDER_BIN = os.getenv("SUBFINDER_BIN", "subfinder")
PUREDNS_BIN = os.getenv("PUREDNS_BIN", "puredns")
RESOLVERS_FILE = os.getenv("RESOLVERS_FILE", "resolvers.txt")
SUBFINDER_TIMEOUT = int(os.getenv("SUBFINDER_TIMEOUT", "120"))
PUREDNS_TIMEOUT = int(os.getenv("PUREDNS_TIMEOUT", "180"))
SUBFINDER_ALL = os.getenv("SUBFINDER_ALL", "true").strip().lower() == "true"
SUBFINDER_RECURSIVE = os.getenv("SUBFINDER_RECURSIVE", "false").strip().lower() == "true"
SAVE_DISCOVERIES = os.getenv("SAVE_DISCOVERIES", "true").strip().lower() == "true"

HOST_RE = re.compile(r"^[a-z0-9][a-z0-9\.\-]{1,251}[a-z0-9]$")


def norm(s: str) -> str:
    return (s or "").strip().lower().rstrip(".")


def extract_host_base(identifier: str) -> str:
    ident = norm(identifier)
    if ident.startswith("http://") or ident.startswith("https://"):
        p = urlparse(ident)
        return norm(p.netloc)
    ident = ident.split("/")[0]
    ident = ident.replace("*.", "").replace("*", "")
    return norm(ident)


def plausible_domain(d: str) -> bool:
    d = norm(d)
    if not d or "." not in d:
        return False
    if len(d) > 253:
        return False
    return bool(HOST_RE.match(d))


def fetch_program_root_domains(cur):
    """
    Returns list of (program_external_id, root_domain).
    Uses scopes table.
    """
    bounty_filter = "AND p.offers_bounties = true" if ONLY_BOUNTY else ""
    cur.execute(
        f"""
        SELECT DISTINCT s.program_external_id, s.identifier
        FROM scopes s
        JOIN programs p ON p.platform=s.platform AND p.external_id=s.program_external_id
        WHERE s.platform='hackerone'
          {bounty_filter}
          AND s.eligible_for_bounty = true
          AND (s.eligible_for_submission = true OR s.eligible_for_submission IS NULL)
        """
    )
    roots = []
    seen = set()
    for program_id, ident in cur.fetchall():
        rd = extract_host_base(ident)
        if plausible_domain(rd):
            key = (program_id, rd)
            if key not in seen:
                seen.add(key)
                roots.append(key)
    return roots


def run_subfinder(root_domain: str) -> list[str]:
    cmd = [SUBFINDER_BIN, "-silent", "-d", root_domain]
    if SUBFINDER_ALL:
        cmd.append("-all")
    if SUBFINDER_RECURSIVE:
        cmd.append("-recursive")

    p = subprocess.run(cmd, capture_output=True, text=True, timeout=SUBFINDER_TIMEOUT)
    out = []
    for line in p.stdout.splitlines():
        d = norm(line)
        if plausible_domain(d) and d.endswith(root_domain):
            out.append(d)
    return sorted(set(out))


def run_puredns_resolve(domains: list[str]) -> set[str]:
    if not domains:
        return set()

    with tempfile.NamedTemporaryFile("w+", delete=False) as fin:
        for d in domains:
            fin.write(d + "\n")
        fin.flush()
        in_path = fin.name

    with tempfile.NamedTemporaryFile("w+", delete=False) as fout:
        out_path = fout.name

    cmd = [
        PUREDNS_BIN, "resolve", in_path,
        "-r", RESOLVERS_FILE,
        "--write", out_path,
        "--rate-limit", "0",
    ]

    subprocess.run(cmd, capture_output=True, text=True, timeout=PUREDNS_TIMEOUT)

    resolved = set()
    with open(out_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            d = norm(line)
            if plausible_domain(d):
                resolved.add(d)
    return resolved


def upsert_targets(cur, program_external_id: str, hosts: set[str], root_domain: str) -> int:
    """
    IMPORTANT: targets table does NOT have 'source' anymore.
    We only insert core fields + timestamps.
    """
    added = 0
    for h in hosts:
        cur.execute(
            """
            INSERT INTO targets(platform, program_external_id, source_scope_identifier, host, first_seen_at, last_seen_at)
            VALUES ('hackerone', %s, %s, %s, now(), now())
            ON CONFLICT (platform, program_external_id, host)
            DO UPDATE SET
              last_seen_at=now(),
              source_scope_identifier=EXCLUDED.source_scope_identifier
            """,
            (program_external_id, root_domain, h),
        )
        added += 1
    return added


def save_discoveries(cur, program_external_id: str, root_domain: str, subs: list[str]) -> None:
    if not SAVE_DISCOVERIES:
        return
    try:
        for s in subs:
            cur.execute(
                """
                INSERT INTO subdomain_discoveries(platform, program_external_id, root_domain, subdomain, source, first_seen_at, last_seen_at)
                VALUES ('hackerone', %s, %s, %s, 'subfinder', now(), now())
                ON CONFLICT (platform, program_external_id, subdomain)
                DO UPDATE SET last_seen_at=now()
                """,
                (program_external_id, root_domain, s),
            )
    except Exception:
        return


def main():
    total_roots = 0
    total_candidates = 0
    total_resolved = 0
    total_targets_added = 0

    with psycopg.connect(DB_DSN) as conn:
        with conn.cursor() as cur:
            roots = fetch_program_root_domains(cur)

        print(f"[INFO] ONLY_BOUNTY_PROGRAMS={ONLY_BOUNTY} roots_to_enum={len(roots)}")
        total_roots = len(roots)

        with conn.cursor() as cur:
            for i, (program_id, root_domain) in enumerate(roots, start=1):
                print(f"[{i}/{total_roots}] subfinder -d {root_domain} (program={program_id})")

                subs = run_subfinder(root_domain)
                total_candidates += len(subs)
                save_discoveries(cur, program_id, root_domain, subs)

                resolved = run_puredns_resolve(subs)
                total_resolved += len(resolved)

                added = upsert_targets(cur, program_id, resolved, root_domain)
                total_targets_added += added

                conn.commit()
                print(f"    candidates={len(subs)} resolved={len(resolved)} targets_upserted={added}")

        print(f"[DONE] roots={total_roots} candidates={total_candidates} resolved={total_resolved} targets_upserted={total_targets_added}")


if __name__ == "__main__":
    main()
