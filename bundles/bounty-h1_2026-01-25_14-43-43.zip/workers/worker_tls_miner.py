#!/usr/bin/env python3
"""
Worker: TLS certificate SAN mining

Input:
- targets

Output:
- tls_certs_latest
- SAN domains usable as new recon candidates

Notes:
- Passive (TLS handshake only)
- No HTTP requests
- Idempotent (latest-only)
"""

import os
import re
import subprocess
import psycopg
from dotenv import load_dotenv
from datetime import datetime

load_dotenv(".env")
DB_DSN = os.getenv("DB_DSN")

TLS_PORTS = [443, 8443]
TIMEOUT_SEC = 8


SAN_RE = re.compile(r"DNS:([^,]+)")


def fetch_targets(cur):
    cur.execute("""
        SELECT id, host
        FROM targets
        ORDER BY last_seen_at DESC
    """)
    return cur.fetchall()


def run_openssl(host: str, port: int):
    cmd = [
        "openssl", "s_client",
        "-connect", f"{host}:{port}",
        "-servername", host,
        "-showcerts",
        "-brief"
    ]
    try:
        p = subprocess.run(
            cmd,
            input="Q",
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SEC
        )
        return p.stdout
    except Exception:
        return None


def parse_cert(output: str):
    issuer = subject = None
    not_before = not_after = None
    san_domains = []

    for line in output.splitlines():
        if line.startswith("issuer="):
            issuer = line.replace("issuer=", "").strip()
        elif line.startswith("subject="):
            subject = line.replace("subject=", "").strip()
        elif "NotBefore" in line:
            not_before = line.split("NotBefore:")[-1].strip()
        elif "NotAfter" in line:
            not_after = line.split("NotAfter:")[-1].strip()
        elif "DNS:" in line:
            san_domains.extend(SAN_RE.findall(line))

    # dedup & normalize
    san_domains = sorted({d.lower().strip() for d in san_domains})

    def parse_dt(s):
        if not s:
            return None
        try:
            return datetime.strptime(s, "%b %d %H:%M:%S %Y %Z")
        except Exception:
            return None

    return issuer, subject, parse_dt(not_before), parse_dt(not_after), san_domains


def upsert_tls(cur, target_id, port, issuer, subject, nb, na, sans):
    cur.execute("""
        INSERT INTO tls_certs_latest(
          target_id, port, issuer, subject, not_before, not_after, san_domains, last_seen_at
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,now())
        ON CONFLICT (target_id) DO UPDATE SET
          port=EXCLUDED.port,
          issuer=EXCLUDED.issuer,
          subject=EXCLUDED.subject,
          not_before=EXCLUDED.not_before,
          not_after=EXCLUDED.not_after,
          san_domains=EXCLUDED.san_domains,
          last_seen_at=now()
    """, (
        target_id, port, issuer, subject, nb, na, sans
    ))


def main():
    with psycopg.connect(DB_DSN) as conn:
        with conn.cursor() as cur:
            targets = fetch_targets(cur)

        done = 0
        with conn.cursor() as cur:
            for tid, host in targets:
                for port in TLS_PORTS:
                    out = run_openssl(host, port)
                    if not out:
                        continue

                    parsed = parse_cert(out)
                    if not parsed:
                        continue

                    issuer, subject, nb, na, sans = parsed
                    if not sans:
                        continue

                    upsert_tls(cur, tid, port, issuer, subject, nb, na, sans)
                    done += 1

                if done % 50 == 0:
                    conn.commit()
                    print(f"[PROGRESS] tls enriched={done}")

            conn.commit()

    print(f"[DONE] TLS/SAN mining completed ({done})")


if __name__ == "__main__":
    main()

