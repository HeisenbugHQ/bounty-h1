#!/usr/bin/env python3
"""
workers/worker_san_correlate.py

Correlate TLS SAN domains -> san_candidates -> (optional) promote into targets if in-scope.

Requires tables:
  - tls_certs_latest (san_domains[])
  - san_candidates
  - san_promotions
  - targets
  - v_scope_domains (host_base)

IMPORTANT: targets.source column has been removed.
This worker must NOT reference it.

Env (.env):
  DB_DSN=postgresql://bounty:bounty@127.0.0.1:5432/bountydb

Optional:
  SAN_BATCH=200
  SAN_MIN_CONFIDENCE=50
  SAN_PROMOTE_IN_SCOPE=true
"""

import os
import re
from datetime import datetime
from typing import Iterable, Optional

import psycopg
from dotenv import load_dotenv

load_dotenv(".env")

DB_DSN = os.getenv("DB_DSN")
if not DB_DSN:
    raise RuntimeError("Missing DB_DSN in .env")

SAN_BATCH = int(os.getenv("SAN_BATCH", "200"))
SAN_MIN_CONFIDENCE = int(os.getenv("SAN_MIN_CONFIDENCE", "50"))
SAN_PROMOTE_IN_SCOPE = os.getenv("SAN_PROMOTE_IN_SCOPE", "true").strip().lower() == "true"

HOST_RE = re.compile(r"^[a-z0-9][a-z0-9\.\-]{1,251}[a-z0-9]$", re.I)


def norm(s: str) -> str:
    return (s or "").strip().lower().rstrip(".")


def plausible_domain(d: str) -> bool:
    d = norm(d)
    if not d or "." not in d:
        return False
    if len(d) > 253:
        return False
    return bool(HOST_RE.match(d))


def registrable_guess(domain: str) -> str:
    """
    Cheap registrable-domain approximation (no PSL dependency):
    keep last 2 labels. It's not perfect for co.uk, etc.
    Good enough for triage/metadata.
    """
    parts = norm(domain).split(".")
    if len(parts) < 2:
        return norm(domain)
    return ".".join(parts[-2:])


def ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


def fetch_scope_bases(cur, platform: str, program_external_id: str) -> list[str]:
    cur.execute(
        """
        SELECT DISTINCT host_base
        FROM v_scope_domains
        WHERE platform=%s AND program_external_id=%s
          AND host_base IS NOT NULL AND host_base <> ''
        """,
        (platform, program_external_id),
    )
    return [norm(r[0]) for r in cur.fetchall() if r and r[0]]


def in_scope(domain: str, scope_bases: Iterable[str]) -> bool:
    d = norm(domain)
    for base in scope_bases:
        b = norm(base)
        if not b:
            continue
        if d == b or d.endswith("." + b):
            return True
    return False


def fetch_tls_san_queue(cur, limit: int):
    """
    Queue = targets where:
      - tls_certs_latest exists with san_domains
      - target.san_scanned_at IS NULL (not processed yet)
    """
    cur.execute(
        """
        SELECT
          t.id AS source_target_id,
          t.platform,
          t.program_external_id,
          t.host AS source_host,
          c.port AS source_port,
          c.san_domains
        FROM targets t
        JOIN tls_certs_latest c ON c.target_id=t.id
        WHERE t.san_scanned_at IS NULL
          AND c.san_domains IS NOT NULL
          AND array_length(c.san_domains, 1) > 0
        ORDER BY t.id
        LIMIT %s
        """,
        (limit,),
    )
    return cur.fetchall()


def upsert_san_candidate(
    cur,
    platform: str,
    program_external_id: str,
    san_domain: str,
    source_target_id: int,
    source_host: str,
    source_port: int,
    confidence: int,
    reasons: dict,
):
    cur.execute(
        """
        INSERT INTO san_candidates(
          platform, program_external_id, san_domain, registrable_domain,
          source_target_id, source_host, source_port,
          confidence, reasons, status,
          first_seen_at, last_seen_at
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'new',now(),now())
        ON CONFLICT (platform, program_external_id, san_domain)
        DO UPDATE SET
          last_seen_at=now(),
          confidence=GREATEST(san_candidates.confidence, EXCLUDED.confidence),
          reasons = san_candidates.reasons || EXCLUDED.reasons
        """,
        (
            platform,
            program_external_id,
            san_domain,
            registrable_guess(san_domain),
            source_target_id,
            norm(source_host),
            int(source_port),
            int(confidence),
            psycopg.types.json.Json(reasons),
        ),
    )


def promote_target(cur, platform: str, program_external_id: str, host: str, scope_hint: Optional[str]) -> int:
    """
    Insert into targets without 'source'. Returns promoted target id.
    """
    cur.execute(
        """
        INSERT INTO targets(platform, program_external_id, source_scope_identifier, host, first_seen_at, last_seen_at)
        VALUES (%s,%s,%s,%s,now(),now())
        ON CONFLICT (platform, program_external_id, host)
        DO UPDATE SET
          last_seen_at=now(),
          source_scope_identifier=COALESCE(EXCLUDED.source_scope_identifier, targets.source_scope_identifier)
        RETURNING id
        """,
        (platform, program_external_id, scope_hint, norm(host)),
    )
    return int(cur.fetchone()[0])


def mark_source_processed(cur, source_target_id: int):
    cur.execute(
        "UPDATE targets SET san_scanned_at=now() WHERE id=%s",
        (source_target_id,),
    )


def insert_promotion(cur, candidate_id: int, promoted_target_id: int, note: str = ""):
    cur.execute(
        """
        INSERT INTO san_promotions(candidate_id, promoted_target_id, promoted_at, note)
        VALUES (%s,%s,now(),%s)
        """,
        (candidate_id, promoted_target_id, note),
    )


def main():
    processed = 0
    promoted = 0
    rejected = 0

    with psycopg.connect(DB_DSN) as conn:
        with conn.cursor() as cur:
            batch = fetch_tls_san_queue(cur, SAN_BATCH)

        print(f"[{ts()}] [INFO] TLS SAN rows fetched: {len(batch)}")

        if not batch:
            print(f"[{ts()}] [DONE] processed=0 promoted=0 rejected=0")
            return

        with conn.cursor() as cur:
            for row in batch:
                source_target_id, platform, program_external_id, source_host, source_port, san_domains = row
                platform = norm(platform)
                program_external_id = str(program_external_id)

                # Load scope bases once per program in this batch row
                bases = fetch_scope_bases(cur, platform, program_external_id)

                # Process SANs
                for raw in (san_domains or []):
                    d = norm(raw)
                    if not plausible_domain(d):
                        continue

                    # Confidence rules (simple, deterministic)
                    conf = 50
                    reasons = {"from": "tls_san", "source_host": norm(source_host), "source_port": int(source_port)}

                    # If in scope -> higher confidence
                    if in_scope(d, bases):
                        conf = 90
                        reasons["in_scope"] = True
                    else:
                        reasons["in_scope"] = False

                    if conf < SAN_MIN_CONFIDENCE:
                        rejected += 1
                        continue

                    upsert_san_candidate(
                        cur,
                        platform=platform,
                        program_external_id=program_external_id,
                        san_domain=d,
                        source_target_id=int(source_target_id),
                        source_host=source_host,
                        source_port=int(source_port),
                        confidence=conf,
                        reasons=reasons,
                    )

                    processed += 1

                    # Promote only if in-scope (default)
                    if SAN_PROMOTE_IN_SCOPE and reasons.get("in_scope") is True:
                        # scope_hint: choose the best matching base (first that matches)
                        hint = None
                        for b in bases:
                            if d == b or d.endswith("." + b):
                                hint = b
                                break

                        # Get candidate id (for promotion link)
                        cur.execute(
                            """
                            SELECT id FROM san_candidates
                            WHERE platform=%s AND program_external_id=%s AND san_domain=%s
                            """,
                            (platform, program_external_id, d),
                        )
                        cand_id = cur.fetchone()
                        if cand_id:
                            cand_id = int(cand_id[0])
                            new_target_id = promote_target(cur, platform, program_external_id, d, hint)
                            insert_promotion(cur, cand_id, new_target_id, note="auto-promoted (in-scope SAN)")
                            # Mark candidate status
                            cur.execute(
                                "UPDATE san_candidates SET status='promoted', last_seen_at=now() WHERE id=%s",
                                (cand_id,),
                            )
                            promoted += 1

                # Mark the source target as SAN-processed (queue control)
                mark_source_processed(cur, int(source_target_id))
                conn.commit()

    print(f"[{ts()}] [DONE] processed={processed} promoted={promoted} rejected={rejected}")


if __name__ == "__main__":
    main()
