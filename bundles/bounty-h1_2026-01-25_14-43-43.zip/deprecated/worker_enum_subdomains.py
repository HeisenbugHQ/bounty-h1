#!/usr/bin/env python3
"""
Worker: Subdomain enumeration (HackerOne scopes -> targets)

Cosa fa:
- Legge wildcard scope paganti (view v_bounty_wildcards)
- Normalizza '*.example.com' -> 'example.com'
- Lancia subfinder per quel dominio
- Inserisce/aggiorna targets (upsert):
  - se nuovo: first_seen_at=now
  - se già noto: aggiorna last_seen_at
- Mantiene provenance:
  - program_external_id
  - source_scope_identifier (il wildcard originale)
  - source = 'subfinder'

Note operative:
- Non filtra sui soli 200: qui stiamo creando inventory host, non "alive web".
- Questo worker è pensato per girare regolarmente (cronjob).
"""

import os
import re
import subprocess
import time
from typing import List, Tuple, Optional

import psycopg
from dotenv import load_dotenv

load_dotenv(dotenv_path=".env")

DB_DSN = os.getenv("DB_DSN")
if not DB_DSN:
    raise RuntimeError("Missing DB_DSN in .env")

SUBFINDER_BIN = os.getenv("SUBFINDER_BIN", "subfinder")
SUBFINDER_TIMEOUT_SEC = int(os.getenv("SUBFINDER_TIMEOUT_SEC", "180"))

# Throttle leggero tra scope (se hai tanti programmi e vuoi essere gentile)
SLEEP_BETWEEN_SCOPES_SEC = float(os.getenv("SLEEP_BETWEEN_SCOPES_SEC", "0.05"))

# Limite di sicurezza: evita che un singolo scope enorme ti butti dentro milioni di righe in un colpo
MAX_HOSTS_PER_SCOPE = int(os.getenv("MAX_HOSTS_PER_SCOPE", "20000"))


def normalize_wildcard_to_domain(scope_identifier: str) -> Optional[str]:
    """
    Esempi:
      '*.example.com' -> 'example.com'
      '*.*.example.com' -> 'example.com' (approssimazione)
      'https://*.example.com' -> 'example.com'
    """
    s = scope_identifier.strip().lower()

    # rimuovi schema e path se presenti
    s = re.sub(r"^https?://", "", s)
    s = s.split("/")[0]

    # se contiene *, prova a togliere tutto fino all'ultimo '*.'
    # caso tipico: *.example.com
    if "*" not in s:
        return None

    # rimuovi caratteri non utili
    s = s.replace(" ", "")

    # prendi la parte dopo l'ultimo "*."
    if "*." in s:
        base = s.split("*.")[-1]
    else:
        # caso raro: *example.com -> example.com
        base = s.replace("*", "")

    base = base.strip(".")
    if not base or "." not in base:
        return None
    return base


def run_subfinder(domain: str) -> List[str]:
    """
    Esegue subfinder su un dominio base e ritorna lista di host.
    """
    cmd = [
        SUBFINDER_BIN,
        "-d", domain,
        "-silent",
        "-all",
    ]

    try:
        p = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=SUBFINDER_TIMEOUT_SEC,
            check=False,
        )
    except subprocess.TimeoutExpired:
        print(f"[WARN] subfinder timeout for domain={domain}")
        return []

    if p.returncode != 0 and p.stderr:
        # subfinder a volte scrive warning su stderr, non sempre è fatal
        print(f"[WARN] subfinder rc={p.returncode} domain={domain} stderr={p.stderr[:160]}")

    hosts = []
    for line in p.stdout.splitlines():
        h = line.strip().lower()
        if not h:
            continue
        # sanity: solo hostname plausibili
        if " " in h or "/" in h:
            continue
        hosts.append(h)

    # dedup preservando ordine
    seen = set()
    out = []
    for h in hosts:
        if h not in seen:
            seen.add(h)
            out.append(h)

    return out


def upsert_target(cur, program_external_id: str, scope_identifier: str, host: str, source: str = "subfinder"):
    """
    Upsert latest-only:
    - se esiste aggiorna last_seen_at e provenance minima
    - se non esiste inserisce con first_seen_at
    """
    cur.execute(
        """
        INSERT INTO targets(platform, program_external_id, source_scope_identifier, host, source, first_seen_at, last_seen_at)
        VALUES ('hackerone', %s, %s, %s, %s, now(), now())
        ON CONFLICT (platform, program_external_id, host)
        DO UPDATE SET
          last_seen_at = now(),
          source_scope_identifier = EXCLUDED.source_scope_identifier,
          source = EXCLUDED.source
        """,
        (program_external_id, scope_identifier, host, source),
    )


def fetch_bounty_wildcards(cur) -> List[Tuple[str, str, str]]:
    """
    Ritorna lista di tuple:
      (program_external_id, program_handle, scope_identifier)
    """
    cur.execute(
        """
        SELECT program_external_id, program_handle, scope_identifier
        FROM v_bounty_wildcards
        ORDER BY program_handle, scope_identifier
        """
    )
    return cur.fetchall()


def main():
    start = time.time()
    total_scopes = 0
    total_hosts_found = 0
    total_targets_upserted = 0

    with psycopg.connect(DB_DSN) as conn:
        with conn.cursor() as cur:
            rows = fetch_bounty_wildcards(cur)

        total_scopes = len(rows)
        print(f"[INFO] Loaded {total_scopes} bounty wildcard scopes")

        with conn.cursor() as cur:
            for i, (program_external_id, program_handle, scope_identifier) in enumerate(rows, start=1):
                base_domain = normalize_wildcard_to_domain(scope_identifier)
                if not base_domain:
                    continue

                print(f"[{i}/{total_scopes}] program={program_handle} scope={scope_identifier} -> base={base_domain}")

                hosts = run_subfinder(base_domain)
                if not hosts:
                    continue

                if len(hosts) > MAX_HOSTS_PER_SCOPE:
                    print(f"[WARN] scope produced {len(hosts)} hosts, truncating to {MAX_HOSTS_PER_SCOPE}")
                    hosts = hosts[:MAX_HOSTS_PER_SCOPE]

                total_hosts_found += len(hosts)

                for h in hosts:
                    upsert_target(cur, program_external_id, scope_identifier, h, source="subfinder")
                    total_targets_upserted += 1

                conn.commit()
                print(f"    hosts={len(hosts)} (cum targets upserted={total_targets_upserted})")

                if SLEEP_BETWEEN_SCOPES_SEC:
                    time.sleep(SLEEP_BETWEEN_SCOPES_SEC)

    elapsed = time.time() - start
    print(f"[DONE] scopes={total_scopes} hosts_found={total_hosts_found} targets_upserted={total_targets_upserted} elapsed={elapsed:.1f}s")


if __name__ == "__main__":
    main()