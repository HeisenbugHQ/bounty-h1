#!/usr/bin/env python3
"""
Worker: HTTP probe (targets -> http_observations)

- Input: targets
- Tool: httpx
- Output: http_observations (latest per URL)
- Salva: status, title, server, tech json
"""

import os
import json
import subprocess
import psycopg
from dotenv import load_dotenv

load_dotenv(".env")
DB_DSN = os.getenv("DB_DSN")
HTTPX_BIN = os.getenv("HTTPX_BIN", "httpx")

HTTPX_PORTS = "80,443,8080,8443,8000,8888"
HTTPX_TIMEOUT = "10"

def fetch_targets(cur):
    cur.execute("""
        SELECT id, host
        FROM targets
        ORDER BY last_seen_at DESC
    """)
    return cur.fetchall()

def run_httpx(hosts):
    cmd = [
        HTTPX_BIN,
        "-silent",
        "-json",
        "-ports", HTTPX_PORTS,
        "-timeout", HTTPX_TIMEOUT,
        "-title",
        "-tech-detect",
        "-status-code",
        "-server",
    ]
    p = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        text=True
    )
    p.stdin.write("\n".join(hosts))
    p.stdin.close()
    return p.stdout

def upsert_http(cur, target_id, r):
    cur.execute("""
        INSERT INTO http_observations(
            target_id, scheme, port, url,
            status_code, title, server_header, tech_json
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT DO NOTHING
    """, (
        target_id,
        r.get("scheme"),
        r.get("port"),
        r.get("url"),
        r.get("status_code"),
        r.get("title"),
        r.get("server"),
        json.dumps(r.get("tech", {}))
    ))

def main():
    with psycopg.connect(DB_DSN) as conn:
        with conn.cursor() as cur:
            targets = fetch_targets(cur)

        host_map = {h: tid for tid, h in targets}
        stdout = run_httpx(list(host_map.keys()))

        with conn.cursor() as cur:
            for line in stdout:
                r = json.loads(line)
                host = r.get("host")
                if host not in host_map:
                    continue
                upsert_http(cur, host_map[host], r)

            conn.commit()

    print("[DONE] http probe completed")

if __name__ == "__main__":
    main()
