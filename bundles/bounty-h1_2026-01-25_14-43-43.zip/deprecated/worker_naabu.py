#!/usr/bin/env python3
"""
Worker: Port scan (targets -> ports_latest)
"""

import os
import subprocess
import psycopg
from dotenv import load_dotenv

load_dotenv(".env")
DB_DSN = os.getenv("DB_DSN")
NAABU_BIN = os.getenv("NAABU_BIN", "naabu")
MODE = os.getenv("NAABU_MODE", "top")  # top | full

def fetch_targets(cur):
    cur.execute("SELECT id, host FROM targets")
    return cur.fetchall()

def main():
    with psycopg.connect(DB_DSN) as conn:
        with conn.cursor() as cur:
            targets = fetch_targets(cur)

        host_map = {h: tid for tid, h in targets}

        cmd = [NAABU_BIN, "-silent"]
        if MODE == "full":
            cmd += ["-p", "-"]
        else:
            cmd += ["-top-ports", "1000"]

        p = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True
        )
        p.stdin.write("\n".join(host_map.keys()))
        p.stdin.close()

        with conn.cursor() as cur:
            for line in p.stdout:
                host, port = line.strip().split(":")
                cur.execute("""
                    INSERT INTO ports_latest(target_id, port)
                    VALUES (%s,%s)
                    ON CONFLICT (target_id, proto, port)
                    DO UPDATE SET last_seen_at=now()
                """, (host_map[host], int(port)))

            conn.commit()

    print("[DONE] port scan completed")

if __name__ == "__main__":
    main()
