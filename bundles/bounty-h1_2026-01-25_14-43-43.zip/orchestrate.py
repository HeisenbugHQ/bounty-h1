#!/usr/bin/env python3
"""
Queue-aware orchestrator.

Runs workers in rounds until:
- no pending items remain OR
- no progress observed in a full round OR
- max rounds reached

It is intentionally simple: subprocess calls + DB counters.

Env:
  DB_DSN (required, same as workers)
  MAX_ROUNDS=10
  SLEEP_BETWEEN_ROUNDS=2

Toggles:
  RUN_TLS=true/false
  RUN_SAN=true/false
  RUN_SAN_LEARN=true/false
  RUN_PARAMS=true/false
  RUN_WAYBACK=true/false
  RUN_EDGE_FP=true/false

Optional (not enforced in sync anymore, kept for display only):
  H1_PROGRAM_ALLOWLIST=stripchat
"""

import os
import sys
import time
import subprocess
from dataclasses import dataclass
from datetime import datetime

import psycopg
from dotenv import load_dotenv

load_dotenv(".env")

DB_DSN = os.getenv("DB_DSN")
if not DB_DSN:
    raise RuntimeError("Missing DB_DSN in .env")

MAX_ROUNDS = int(os.getenv("MAX_ROUNDS", "10"))
SLEEP_BETWEEN_ROUNDS = float(os.getenv("SLEEP_BETWEEN_ROUNDS", "2"))

RUN_TLS = os.getenv("RUN_TLS", "true").strip().lower() == "true"
RUN_SAN = os.getenv("RUN_SAN", "true").strip().lower() == "true"
RUN_SAN_LEARN = os.getenv("RUN_SAN_LEARN", "true").strip().lower() == "true"
RUN_PARAMS = os.getenv("RUN_PARAMS", "true").strip().lower() == "true"
RUN_WAYBACK = os.getenv("RUN_WAYBACK", "true").strip().lower() == "true"
RUN_EDGE_FP = os.getenv("RUN_EDGE_FP", "true").strip().lower() == "true"

BASE_STEPS = [
    ("sync_h1", ["python", "sync_h1.py"]),
    ("subdomains_resolve", ["python", "workers/worker_subdomains_resolve.py"]),
]

ROUND_STEPS = [
    ("http_probe", ["python", "workers/worker_http_reinject.py"]),
    ("wayback_urls", ["python", "workers/worker_wayback_urls.py"]),
    ("edge_fingerprint", ["python", "workers/worker_edge_fingerprint.py"]),
    ("port_scan", ["python", "workers/worker_port_reinject.py"]),
    ("enrich_dns_asn", ["python", "workers/worker_enrich_dns_asn.py"]),
]

TLS_STEPS = [
    ("tls_miner", ["python", "workers/worker_tls_miner.py"]),
]

SAN_STEPS = [
    ("san_correlate", ["python", "workers/worker_san_correlate.py"]),
]

SAN_LEARN_STEPS = [
    ("san_learn", ["python", "workers/worker_learn_from_san.py"]),
]

PARAM_STEPS = [
    ("param_html", ["python", "workers/worker_param_mine_html.py"]),
    ("param_js", ["python", "workers/worker_param_mine_js.py"]),
]


@dataclass(frozen=True)
class Counts:
    http_pending: int
    port_pending: int
    js_pending: int
    targets_total: int
    http_obs_total: int
    ports_total: int

    def key(self):
        return (
            self.http_pending,
            self.port_pending,
            self.js_pending,
            self.targets_total,
            self.http_obs_total,
            self.ports_total,
        )


def ts():
    return datetime.now().strftime("%H:%M:%S")


def run_step(name, cmd):
    print(f"[{ts()}] [RUN] {name}: {' '.join(cmd)}")
    p = subprocess.run(cmd)
    if p.returncode != 0:
        print(f"[{ts()}] [FAIL] {name} exit={p.returncode}")
        sys.exit(p.returncode)
    print(f"[{ts()}] [OK ] {name}")


def get_counts() -> Counts:
    with psycopg.connect(DB_DSN) as conn:
        with conn.cursor() as cur:
            # expects v_counts_queue(http_pending, port_pending, js_pending)
            cur.execute("SELECT http_pending, port_pending, js_pending FROM v_counts_queue;")
            http_pending, port_pending, js_pending = cur.fetchone()

            cur.execute("SELECT count(*) FROM targets WHERE platform='hackerone';")
            targets_total = cur.fetchone()[0]

            cur.execute("SELECT count(*) FROM http_observations;")
            http_obs_total = cur.fetchone()[0]

            cur.execute("SELECT count(*) FROM ports_latest;")
            ports_total = cur.fetchone()[0]

    return Counts(
        http_pending=int(http_pending),
        port_pending=int(port_pending),
        js_pending=int(js_pending),
        targets_total=int(targets_total),
        http_obs_total=int(http_obs_total),
        ports_total=int(ports_total),
    )


def queues_empty(c: Counts) -> bool:
    # "js_pending" is optional signal; keep it but do not overfit logic on it.
    return (c.http_pending == 0 and c.port_pending == 0 and c.js_pending == 0)


def main():
    if os.path.exists(".venv") and os.environ.get("VIRTUAL_ENV") is None:
        print("[WARN] .venv exists but not activated. You likely want: source .venv/bin/activate")

    print(f"[{ts()}] Queue-aware orchestrator starting...")
    allow = os.getenv("H1_PROGRAM_ALLOWLIST")
    if allow:
        print(f"[{ts()}] H1_PROGRAM_ALLOWLIST={allow}")

    for name, cmd in BASE_STEPS:
        run_step(name, cmd)

    prev = get_counts()
    print(f"[{ts()}] Initial counts: {prev}")

    for round_i in range(1, MAX_ROUNDS + 1):
        print(f"[{ts()}] ===== ROUND {round_i}/{MAX_ROUNDS} =====")
        before = get_counts()
        print(f"[{ts()}] Before round: {before}")

        # Core repeated steps, with minimal "skip when pointless"
        for name, cmd in ROUND_STEPS:
            if name == "http_probe":
                now = get_counts()
                if now.http_pending == 0:
                    print(f"[{ts()}] [SKIP] http_probe (no http_pending)")
                    continue

            if name == "wayback_urls":
                if not RUN_WAYBACK or not os.path.exists("workers/worker_wayback_urls.py"):
                    print(f"[{ts()}] [SKIP] wayback_urls (disabled or missing)")
                    continue

            if name == "edge_fingerprint":
                if not RUN_EDGE_FP or not os.path.exists("workers/worker_edge_fingerprint.py"):
                    print(f"[{ts()}] [SKIP] edge_fingerprint (disabled or missing)")
                    continue

            if name == "port_scan":
                now = get_counts()
                if now.port_pending == 0:
                    print(f"[{ts()}] [SKIP] port_scan (no port_pending)")
                    continue

            if name == "enrich_dns_asn":
                if not os.path.exists("workers/worker_enrich_dns_asn.py"):
                    print(f"[{ts()}] [SKIP] enrich_dns_asn (missing worker)")
                    continue

            run_step(name, cmd)

        # Optional: TLS/SAN can generate new targets -> which creates new http/port pending
        if RUN_TLS and os.path.exists("workers/worker_tls_miner.py"):
            for name, cmd in TLS_STEPS:
                run_step(name, cmd)

        if RUN_SAN and os.path.exists("workers/worker_san_correlate.py"):
            for name, cmd in SAN_STEPS:
                run_step(name, cmd)

        if RUN_SAN_LEARN and os.path.exists("workers/worker_learn_from_san.py"):
            for name, cmd in SAN_LEARN_STEPS:
                run_step(name, cmd)

        # Params: always run when enabled; do NOT key it off js_pending
        if RUN_PARAMS:
            if os.path.exists("workers/worker_param_mine_html.py"):
                run_step("param_html", ["python", "workers/worker_param_mine_html.py"])
            else:
                print(f"[{ts()}] [SKIP] param_html (missing worker)")

            if os.path.exists("workers/worker_param_mine_js.py"):
                run_step("param_js", ["python", "workers/worker_param_mine_js.py"])
            else:
                print(f"[{ts()}] [SKIP] param_js (missing worker)")

        after = get_counts()
        print(f"[{ts()}] After round:  {after}")

        if queues_empty(after):
            print(f"[{ts()}] Queues empty. Stopping.")
            break

        if after.key() == before.key():
            print(f"[{ts()}] No progress detected in this round. Stopping to avoid infinite loop.")
            break

        time.sleep(SLEEP_BETWEEN_ROUNDS)

    final = get_counts()
    print(f"[{ts()}] FINAL: {final}")
    print(f"[{ts()}] Done.")


if __name__ == "__main__":
    main()
